# Flask API with JSON Web Tokens (JWT)
This application is a demonstration of using JSON Web Tokens to access an API
with Flask
